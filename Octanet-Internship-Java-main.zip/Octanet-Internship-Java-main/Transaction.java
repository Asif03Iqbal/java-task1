public interface Transaction {
    String getDescription();
}