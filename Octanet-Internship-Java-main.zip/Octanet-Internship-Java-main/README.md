# Octanet-Internship-Java
ATM INTERFACE: 
In this project, I have created a console-based application,In orde to use the system,the user must enter his or her User Id and Pin. Once the details are entered successfully, ATM functionality is unlocked.

As a result of the project, the following operations can be performed

> Transaction  History 

> Withdraw 

> Deposit 

> Transfer

> Quit
